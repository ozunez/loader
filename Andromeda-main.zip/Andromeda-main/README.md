![Banner](https://github.com/SeasonalKirito/Andromeda/blob/main/images/andromeda-banner.png?raw=true)
## Loader
> [!CAUTION]
> **Script hub can be discontinued at any time due to lack of importance.**
```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/SeasonalKirito/Andromeda/main/loader.lua"))()
```
